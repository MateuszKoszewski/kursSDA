package pl.sda;


import pl.sda.dao.PersonDao;
import pl.sda.dao.PersonDaoHibernateImpl;
import pl.sda.domain.Person;

import java.util.List;
import java.util.Optional;

public class Application {
    public static void main(String[] args) {

        PersonDao person = new PersonDaoHibernateImpl();
        List<Person> list = person.findAll();
        System.out.println(list.size());

    }
}
